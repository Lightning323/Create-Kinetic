package net.minecraft.client.gui.components.events;

import javax.annotation.Nullable;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.components.TabOrderedElement;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Represents a listener for GUI events.
 * <p>
 * It extends the {@code TabOrderedElement} interface, providing tab order functionality for GUI components.
 */
@OnlyIn(Dist.CLIENT)
public interface GuiEventListener extends TabOrderedElement {
    long DOUBLE_CLICK_THRESHOLD_MS = 250L;

    /**
     * Called when the mouse is moved within the GUI element.
     *
     * @param mouseX the X coordinate of the mouse.
     * @param mouseY the Y coordinate of the mouse.
     */
    default void mouseMoved(double mouseX, double mouseY) {
    }

    default boolean mouseClicked(double p_94737_, double p_94738_, int p_94739_) {
        return false;
    }

    default boolean mouseReleased(double p_94753_, double p_94754_, int p_94755_) {
        return false;
    }

    default boolean mouseDragged(double p_94740_, double p_94741_, int p_94742_, double p_94743_, double p_94744_) {
        return false;
    }

    default boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return false;
    }

    default boolean keyPressed(int p_94745_, int p_94746_, int p_94747_) {
        return false;
    }

    default boolean keyReleased(int p_94750_, int p_94751_, int p_94752_) {
        return false;
    }

    default boolean charTyped(char p_94732_, int p_94733_) {
        return false;
    }

    /**
     * Retrieves the next focus path based on the given focus navigation event.
     * <p>
     * @return the next focus path as a ComponentPath, or {@code null} if there is no next focus path.
     *
     * @param event the focus navigation event.
     */
    @Nullable
    default ComponentPath nextFocusPath(FocusNavigationEvent event) {
        return null;
    }

    /**
     * Checks if the given mouse coordinates are over the GUI element.
     * <p>
     * @return {@code true} if the mouse is over the GUI element, {@code false} otherwise.
     *
     * @param mouseX the X coordinate of the mouse.
     * @param mouseY the Y coordinate of the mouse.
     */
    default boolean isMouseOver(double mouseX, double mouseY) {
        return false;
    }

    /**
     * Sets the focus state of the GUI element.
     *
     * @param focused {@code true} to apply focus, {@code false} to remove focus
     */
    void setFocused(boolean focused);

    boolean isFocused();

    @Nullable
    default ComponentPath getCurrentFocusPath() {
        return this.isFocused() ? ComponentPath.leaf(this) : null;
    }

    default ScreenRectangle getRectangle() {
        return ScreenRectangle.empty();
    }
}
